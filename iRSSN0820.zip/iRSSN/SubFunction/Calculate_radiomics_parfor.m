function Calculate_radiomics_parfor(images, maskpath, savepath)

% -------------------------------------------------------------------------
% DESCRIPTION:
% This function extracts texture features from preprossed sructural MRI data
% based specific atlas, and calculates individualized structural similarity
% network.
% -------------------------------------------------------------------------

%subject = dir(datapath);

% hh = waitbar(0,'Stage:1/2,Calculating the Texture features >>>');
parfor i=1:size(images,1)
    %cd(strcat(subject(i).folder,'\',subject(i).name));
    %load(strcat(subject(i).folder,'\',subject(i).name,'\sMRI.mat'));
    radiomics=[];
    xi=i;
    [~,niiname,~]=fileparts(images(xi).fname);
    disp(strcat(niiname," starting"));
%     s = ['Stage:1/2,Calculating the Texture features:',num2str(100*i/size(images,1)),'%'];
%     waitbar(i/size(images,1),hh,s);
    nii = load_nii(images(i).fname);
    result = double(nii.img);
    rois=load(strcat(maskpath,'\','roi_file.mat'));
    roi_file=rois.roi_file;
%     parpool(12);
%     spmd
    for j=1:size(roi_file,4)
        index=1;
        [ROIonly,levels] = prepareVolume(result,roi_file(:,:,:,j),'MRscan',1.5,1.5,1,1.5,'Matrix','Lloyd',32);
        glcm_mat=getGLCM(ROIonly,levels);
        glcm_texture=getGLCMtextures(glcm_mat);
        glcm_name=fieldnames(glcm_texture);
        %% Extract gray-level co-occurence matrix (GLCM)texture features.
        for k=1:size(glcm_name,1)
            radiomics(j,index)=getfield(glcm_texture,glcm_name{k});
            index=index+1;
        end
        %% Extract gray-level run-length matrix (GLRLM)texture features.
        glrlm_mat=getGLRLM(ROIonly,levels);
        glrlm_texture=getGLRLMtextures(glrlm_mat);
        glrlm_name=fieldnames(glrlm_texture);
        for l=1:size(glrlm_name,1)
            radiomics(j,index)=getfield(glrlm_texture,glrlm_name{l});
            index=index+1;
        end
        %% Extract gray-level Size Zone matrix (GLSZM)texture features.
        glszm_mat=getGLSZM(ROIonly,levels);
        glszm_texture=getGLSZMtextures(glszm_mat);
        glszm_name=fieldnames(glszm_texture);
        for m=1:size(glszm_name,1)
            radiomics(j,index)=getfield(glszm_texture,glszm_name{m});
            index=index+1;
        end
        %% Extract neighbourhood gray-tone difference matrix (NGTDM)texture features.
        [ngtdm_mat,countvalid]=getNGTDM(ROIonly,levels);
        ngtdm_texture=getNGTDMtextures(ngtdm_mat,countvalid);
        ngtdm_name=fieldnames(ngtdm_texture);
        for n=1:size(ngtdm_name,1)
            radiomics(j,index)=getfield(ngtdm_texture,ngtdm_name{n});
            index=index+1;
        end
        %% Extract global texture features (first-order gray-level statistics).
        [ROIonly_glo] = prepareVolume(result,roi_file(:,:,:,j),'MRscan',1.5,1.5,2,1.5,'Global');
        global_texture=getGlobalTextures(ROIonly_glo,32);
        global_name=fieldnames(global_texture);
        for h=1:size(global_name,1)
            radiomics(j,index)=getfield(global_texture,global_name{h});
            index=index+1;
        end
    end
%     end

% close(hh)

%% Calculates individualized structural similarity network
[x,y]=size(radiomics);
mradiomics=zeros(x,y);
for mi=1:x
    mradiomics(mi,:)=radiomics(mi,:)./mean(radiomics(mi,:)); %Normalization
end

% hhh = waitbar(0,'Stage:2/2,Calculating the iRSSN >>>');
fc=zeros(246,246);
pvalue=zeros(246,246);
% for xi=1:x
%     ss = ['Stage:2/2,Calculating the iRSSN:',num2str(100*xi/x),'%'];
%     waitbar(xi/x,hhh,ss);
%    indexsqueeze =1;
    for yi=1:x
        for zi=1:x
            [fc(yi,zi),pvalue(yi,zi)]=corr(mradiomics(yi,:)',mradiomics(zi,:)');
%             if zi > yi
%                 all_fc(xi,indexsqueeze) = fc(yi,zi);
%                 indexsqueeze = indexsqueeze + 1;
%             end
        end
    end


%     sfc=struct("fc",fc);
%     sp=struct("pvalue",pvalue);
    parsave(strcat(savepath,'\iRSSN_',niiname,'.txt'),fc);
    parsave(strcat(savepath,'\P_',niiname,'.txt'),pvalue);
    disp(strcat(niiname," finished"));
% end

% save(strcat(savepath,'\iRSSN_all_data','.mat'),'all_fc');

% close(hhh)
% cd(savepath)
end
