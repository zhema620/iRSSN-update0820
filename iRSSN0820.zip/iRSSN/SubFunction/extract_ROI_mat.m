function [] = extract_ROI_mat(atlas,datapath)

% -------------------------------------------------------------------------
% DESCRIPTION:
% This function extracts ROI information based specific atlas, then makes 
% masks according to the extracted ROI and save the information in each 
% subject folder.
% -------------------------------------------------------------------------

k = max(max(max(atlas)));  % k:the number of ROIs for the atlas 
for i=1:k
    mask=double(atlas==i); % Binary each ROI value based voxel
    roi_file(:,:,:,i)=mask;
end
roi_file(find(roi_file>1))=1;
save(strcat(datapath,'\','roi_file.mat'),'roi_file');

% data=dir(datapath);
% for j=3:size(data,1)
%     copyfile('ROI_4D.mat',strcat(datapath,'\',data(j).name))
% end
end
