    function parsave(fname,x)
    save(fname, 'x','-ascii');
    end