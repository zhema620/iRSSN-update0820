function [] = iRSSN(images, atlas, maskpath, iRSSNpath)
% -------------------------------------------------------------------------
% function [] = iRSSN(files, msk, datapath, iRSSNpath)
% -------------------------------------------------------------------------
% DESCRIPTION: 
% This function builds individualized structural similarity network based   
% radiomics features extracted from processed MRI T1 images 
%-------------------------------------------------------------------------
% REFERENCE:
% [1] Vallieres, M., Freeman, C.R., Skamene, S.R., El Naqa, I., 2015. A 
% radiomics model from joint FDG-PET and MRI texture features for the 
% prediction of lung metastases in soft-tissue sarcomas of the extremities.
% Phys Med Biol 60, 5471-5496.
% -------------------------------------------------------------------------
% INPUTS:   
%   images   - Preprocessed structural MRI grey matter images with nii
%              format in standard space
%   atlas    - Standard brain atlas
%   datapath - the path of the folder to save sorted sMRI data and atlas
%              information of each subject
%   iRSSNpath - the path of the folder to save iRSSN matrix

% Output��
%    In iRSSNpath folder : including the iRSSN matrix and conrresponding P value of each subject 

if exist('spm_select','file') % should be true for spm12
    spm = 1;
    select = @(msg) spm_select(inf, 'image', msg);
elseif exist('spm_get','file') % should be true for spm2
    spm = 0;
    select = @(msg) spm_get(inf, 'img', msg);
else
    error('Failed to locate spm_get or spm_select; please add SPM to Matlab path')
end

if ( ~exist('images', 'var') || isempty(images) )
    images = select('Choose preprocessed sMRI images');
end
if ischar(images)
    images = spm_vol(images);
end

if ( ~exist('atlas', 'var') || isempty(atlas) )
    atlas = select('Choose ROI atlas');
end

if ischar(atlas)
    atlas = spm_vol(atlas);
    atlas = load_nii(atlas.fname);
end

maskpath = uigetdir(path,'Select the folder path to save mask data--the ROI file');
iRSSNpath = uigetdir(path,'Select the folder path to save iRSSN matrix');
%% Extract ROI information based specific atlas and make masks based each ROI 
atlas = atlas.img;
extract_ROI_mat(atlas,maskpath);

%% Calculate individualized structural similarity network based texture features
%parpool(8);
%spmd
Calculate_radiomics_parfor(images,maskpath,iRSSNpath);
%end
disp('The job has been done successfully!')
end
